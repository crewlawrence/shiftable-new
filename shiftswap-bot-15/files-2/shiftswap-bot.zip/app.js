const { App, ExpressReceiver } = require("@slack/bolt");
const { WebClient } = require("@slack/web-api");
const { handleMessage } = require("./agent");
const { saveInstallation, getInstallation, deleteInstallation } = require("./store");
const { migrate } = require("./turso");

// ─── OAuth receiver ───────────────────────────────────────────────────────────

const receiver = new ExpressReceiver({
  signingSecret: process.env.SLACK_SIGNING_SECRET,
  clientId:      process.env.SLACK_CLIENT_ID,
  clientSecret:  process.env.SLACK_CLIENT_SECRET,
  stateSecret:   process.env.SLACK_STATE_SECRET,
  scopes: [
    "chat:write",
    "chat:write.public",
    "im:write",
    "im:read",
    "im:history",
    "users:read",
    "channels:read",
    "channels:history",
    "channels:join",
    "groups:read",
    "groups:history",
    "mpim:write",
    "mpim:read",
  ],
  installerOptions: {
    redirectUriPath: "/slack/oauth_redirect",
    stateVerification: false,
    callbackOptions: {
      success: (installation, installOptions, req, res) => {
        res.send(`
          <html><body style="font-family:sans-serif;text-align:center;padding:60px;background:#0F1523;color:white">
            <h1 style="color:#5B5FFF">✅ Trade AI installed!</h1>
            <p style="color:#8B8FA8;margin-top:12px">Head back to Slack and DM <strong style="color:white">Trade AI</strong> to get started.</p>
          </body></html>
        `);
      },
      failure: (error, installOptions, req, res) => {
        console.error("OAuth failure:", error);
        res.status(500).send(`
          <html><body style="font-family:sans-serif;text-align:center;padding:60px;background:#0F1523;color:white">
            <h1>❌ Installation failed</h1><p style="color:#8B8FA8">${error.message}</p>
          </body></html>
        `);
      },
    },
  },
  installationStore: {
    storeInstallation: async (installation) => {
      await saveInstallation({
        teamId:      installation.team.id,
        teamName:    installation.team.name,
        botToken:    installation.bot.token,
        botUserId:   installation.bot.userId,
        installedAt: new Date().toISOString(),
      });
    },
    fetchInstallation: async (installQuery) => {
      const record = await getInstallation(installQuery.teamId);
      if (!record) throw new Error(`No installation found for team ${installQuery.teamId}`);
      return {
        team: { id: record.teamId, name: record.teamName },
        bot:  { token: record.botToken, userId: record.botUserId },
      };
    },
    deleteInstallation: async (installQuery) => {
      await deleteInstallation(installQuery.teamId);
    },
  },
});

// ─── Bolt app ─────────────────────────────────────────────────────────────────

const app = new App({ receiver });

// ─── Install landing page ─────────────────────────────────────────────────────

const path = require("path");

receiver.router.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// ─── Event handler ────────────────────────────────────────────────────────────

app.message(async ({ message, context }) => {
  console.log("📨 Message received:", JSON.stringify({ type: message.channel_type, user: message.user, bot_id: message.bot_id, text: message.text?.slice(0, 50) }));

  // Listen to DMs and channel messages (candidates reply in channels)
  if (message.channel_type !== "im" && message.channel_type !== "channel") {
    console.log("⏭ Skipped: not a DM or channel");
    return;
  }
  if (message.bot_id) { console.log("⏭ Skipped: bot message"); return; }
  if (!message.user) { console.log("⏭ Skipped: no user"); return; }

  const teamId = context.teamId;
  console.log("🏢 Team ID:", teamId);

  const record = await getInstallation(teamId);
  if (!record) { console.error(`❌ No installation for team ${teamId}`); return; }
  console.log("✅ Installation found for team:", record.teamName);

  const client = new WebClient(record.botToken);

  try {
    await handleMessage({ teamId, message, client });
    console.log("✅ handleMessage completed");
  } catch (err) {
    console.error("❌ handleMessage error:", err.message, err.stack);
  }
});

// ─── Start ────────────────────────────────────────────────────────────────────

const PORT = process.env.PORT || 3000;

(async () => {
  await migrate(); // Create tables in Turso if they don't exist
  await app.start(PORT);
  console.log(`⚡️ Trade AI running on port ${PORT}`);
  console.log(`🔗 ${process.env.APP_URL || `http://localhost:${PORT}`}`);
})();
